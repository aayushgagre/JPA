package com.cg.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.daos.SessionDAO;
import com.cg.entities.Session_Master;
import com.cg.exceptions.ApplicationException;

@Service
@Transactional
public class SessionServiceImpl implements SessionService {

	@Autowired
	private SessionDAO dao;

	/**
	 * Service method for finding the data of the session by providing the ID
	 */
	@Transactional(readOnly = true)
	public Session_Master findById(int id) {
		Optional<Session_Master> session = dao.findById(id);
		if (session.isPresent()) {
			return session.get();
		} else
			throw new RuntimeException("Product not found!");
	}

	/**
	 * Updating the session details
	 */

	/*
	 * @Override public void update(Session s) { // TODO Auto-generated method stub
	 * 
	 * }
	 */

	/**
	 * Creating the new Session in the table
	 */
	public void create(Session_Master s) {
		Session_Master temp = findById(s.getId());
		if (temp == null)
			dao.save(s);
		else
			throw new ApplicationException("Country " + s.getId() + " already exists!");

	}

	/*
	 * Deleting the data of particular session by providing the id. (non-Javadoc)
	 * 
	 * @see com.cg.services.SessionService#deleteById(int)
	 */
	@Override
	public void deleteById(int id) {
		Session_Master session = findById(id);
		dao.delete(session);

	}

	/**
	 * Displaying the data of all sessions
	 */

	@Transactional(readOnly = true)
	public List<Session_Master> findAll() {

		return dao.findAll();
	}

}
