package com.cg.services;

import java.util.List;

import com.cg.entities.Session_Master;

public interface SessionService {

	public Session_Master findById(int id); // Finding By id

	// public void update(Session s); //Updating the session

	public void create(Session_Master s); // Creating the new Session means adding a new Data

	public void deleteById(int id); // Deleting the session by providing Id

	public List<Session_Master> findAll(); // Getting all the sessions details

}
