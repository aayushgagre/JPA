package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Session_Master;
import com.cg.services.SessionService;

@RestController
@RequestMapping("/session")
public class SessionController {

	@Autowired
	SessionService service;

	/**
	 * Finding the session details by entering the ID in the URL
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping(value = "/id/{id}")
	public Session_Master find(@PathVariable int id) {
		return service.findById(id);
	}

	/**
	 * Creating the Session table with following attributes(id, name, duration,
	 * faculty, mode)
	 * 
	 * @param session
	 * @return
	 */

	@RequestMapping(value="/new", method=RequestMethod.POST,consumes= {"application/json"})
	public String save(@RequestBody Session_Master session) {
		service.create(session);
		return "session added!";
	}

	/**
	 * updating the value by providing the id of the session which is unique
	 * contraint
	 * 
	 * @param id
	 * @return
	 */

	/*
	 * @PutMapping(value="/update/{id}",consumes= {"application/json"}) public
	 * String update(@PathVariable int id) { service.update(id); return
	 * "session updated"; }
	 */
	/**
	 * Deleting the session data from the table by providing the ID of the session
	 * 
	 * @param id
	 * @return
	 */

	@DeleteMapping(value = "/delete/{id}", consumes = { "application/json" })
	public String delete(@PathVariable int id) {

		service.deleteById(id);

		return "session deleted";
	}

	/**
	 * Displaying the detail of every session.
	 * 
	 * @return
	 */
	@GetMapping(value = "/view")
	public List<Session_Master> viewAll() {
		return service.findAll();
	}

}
