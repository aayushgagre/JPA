package com.cg.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entities.Session_Master;



public interface SessionDAO extends JpaRepository<Session_Master, Integer> {

}
